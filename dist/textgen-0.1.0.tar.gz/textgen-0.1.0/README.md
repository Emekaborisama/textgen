# Tensor_textgen


A text generation library built on top of tensorflow

Something sweet built with Tensorflow - This is the brain of rosalove ai (rosalove.xyz)
